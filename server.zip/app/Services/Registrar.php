<?php namespace App\Services;

use App\User;
use Validator;

class Registrar {

	/**
	 * Get a validator for an incoming registration request.
	 *
	 * @param  array  $data
	 * @return \Illuminate\Contracts\Validation\Validator
	 */
	public function validator(array $data)
	{
		return Validator::make($data, [
			'email' => 'required|email|max:255|unique:users',
			'password' => 'required|confirmed|min:4',
		]);
	}

	/**
	 * Create a new user instance after a valid registration.
	 *
	 * @param  array  $data
	 * @return User
	 */
	public function create(array $data)
	{
		return User::create([
			'email' => $data['email'],
			'password' => bcrypt($data['password']),
			'username' => isset($data['username']) ? $data['username'] : null,
			'first_name' => isset($data['first_name']) ? $data['first_name'] : null,
			'last_name' => isset($data['last_name']) ? $data['last_name'] : null,
			'gender' => isset($data['gender']) ? $data['gender'] : null,
            'confirmed' => isset($data['confirmed']) ? $data['confirmed'] : 1,
            'confirmation_code' => isset($data['confirmation_code']) ? $data['confirmation_code'] : null,
		]);
	}

}
