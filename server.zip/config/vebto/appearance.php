<?php

return [
    'variables' => [
        'site-accent-color',
        'wp-bg-color-600',
        'wp-bg-color-500',
        'wp-bg-color-400',
        'wp-bg-color-300',
        'wp-bg-color-200',
        'wp-bg-color-100',
        'wp-border-color-200',
        'wp-border-color-100',
        'wp-text-color-300',
        'wp-text-color-200',
        'wp-text-color-100',
    ]
];